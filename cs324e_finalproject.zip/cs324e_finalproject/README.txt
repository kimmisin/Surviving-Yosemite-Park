If sound library is not installed in your Processing environment follow the following steps: 

Sketch -> Import library -> Add library -> search "Sound" -> install Sound by The Processing Foundation

Open file "cs324e_finalproject.pde" and click "Run" to start the game. The game takes a bit to load, please do not press any keys or click on the canvas during this time.

The player’s goal is to survive as long as possible and collect star objects for points. If collision occurs with a log, bear, or rock a life is lost. Bears are cleared by shooting a fireball at it when the charged bar is full. Water must be avoided or the player automatically loses. 

NOTE: for a new map to be randomly chosen again the game must be exited and "Run" needs to be clicked again.

The following are the key controls, tap:
e: pick up the star object
w: jump
a: run left
s: stay in place
d: run left
spacebar: shoot a fireball
x: quit the game (the exit() function takes a second to actually close the game)

Press the top right circular button to pause the game.
